package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@SpringBootApplication
public class SslServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(SslServerApplication.class, args);
    }
}

@RestController
class ServerController {

    // Helper method to convert a byte array into a hex string format
    public String bytesToHex(byte[] bytes) {
        StringBuilder hString = new StringBuilder();
        for (byte bString : bytes) {
            hString.append(String.format("%02x", bString));
        }
        return hString.toString();
    }

    // Secure endpoint mapped to /hash
    @RequestMapping("/hash")
    public String myHash() throws NoSuchAlgorithmException {
        // Data block representing the financial data receipt or message
        String data = "Hello World CheckSum!";
        
        // Use a secure hashing algorithm (SHA-256) to ensure integrity and avoid collisions
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        
        // Compute the hash from the byte array of our static string data
        byte[] hash = md.digest(data.getBytes(StandardCharsets.UTF_8));
        
        // Convert the computed hash bytes to readable hexadecimal structure
        String checkSum = bytesToHex(hash);
        
        // Return information containing the original data, algorithm type, and the unique checksum
        return "data: " + data + " : SHA-256 : " + checkSum;
    }
}
